package com.unity.hw.SelfBuild.Auth;

import com.huawei.agconnect.server.auth.jwt.AGCAuthJwtToken;
import com.huawei.agconnect.server.auth.service.AGCAuth;
import com.huawei.agconnect.server.auth.util.RSAKeyPair;
import com.huawei.agconnect.server.commons.AGCClient;
import com.huawei.agconnect.server.commons.AGCParameter;
import com.huawei.agconnect.server.commons.credential.CredentialParser;
import com.huawei.agconnect.server.commons.credential.CredentialService;

public class GenJWToken {
    private static GenJWToken instance;
    private String privateKey="";
    private String publicKey="";

    public static GenJWToken getInstance()
    {
        return instance==null?instance=new GenJWToken():instance;
    }


    public void initialize(String path)
    {
      try {
            CredentialService credential = CredentialParser.toCredential(path);
            AGCParameter parameter = AGCParameter.builder().setCredential(credential).build();
            AGCClient.initialize(parameter);

        }catch(Exception p){


        }
    }

    public String getToken(String uid,String nickname)
    {
        try {
            AGCAuthJwtToken token = AGCAuth.getInstance().sign(uid, nickname, null, privateKey);
            return token.getToken();
        }catch (Exception e)
        {
            return null;
        }
    }

    public String resetKey()
    {
        try {
            RSAKeyPair rsaKeyPair = AGCAuth.getInstance().generateKey();
            privateKey = rsaKeyPair.getPrivateKey();
            publicKey = rsaKeyPair.getPublicKey();

            return publicKey;
        }catch (Exception e)
        {
            return null;
        }
    }

    public static void main(String[] args)
    {
        if(args.length==0)
        {
            System.out.println("enter your api_client json file path");
        }else {
            GenJWToken.getInstance().initialize(args[0]);
            if(args.length>=2) {
                if (GenJWToken.getInstance().publicKey.equals("")||args[1].equals("1")) {
                    GenJWToken.getInstance().resetKey();
                }
                System.out.println("The public key is:" + GenJWToken.getInstance().publicKey);
                if (args.length < 3) {
                    System.out.println("JWToken is:" + GenJWToken.getInstance().getToken("123", "default"));
                } else {
                    System.out.println("JWToken is:" + GenJWToken.getInstance().getToken(args[2], args[3]));
                }
            }else{
                System.out.println("please enter the correct parameters!");
            }
        }
    }

}
